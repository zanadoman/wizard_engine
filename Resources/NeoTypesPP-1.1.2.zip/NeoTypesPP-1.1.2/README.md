# NeoTypes++
A type library for C++ that includes: new variable names, dynamic array, string, conversion between string and numeric types, and some file/memory management.

# Wiki
