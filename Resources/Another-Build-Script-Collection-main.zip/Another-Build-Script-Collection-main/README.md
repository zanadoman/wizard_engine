# Yet Another Silly Build Script Collection
cbuild - C/C++\
ezdot - C#