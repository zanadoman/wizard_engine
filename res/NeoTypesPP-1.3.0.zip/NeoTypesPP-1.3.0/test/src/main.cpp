#include "../../src/NeoTypes++.hpp"

using namespace neo;

sint32 main()
{
    printf("hello, world!\n");

    return 0;
}