# EZ Script Collection
cbuild - Build script for C/C++
ezdot - Build script for C# console apps
ezgit - Git handler for noobs
